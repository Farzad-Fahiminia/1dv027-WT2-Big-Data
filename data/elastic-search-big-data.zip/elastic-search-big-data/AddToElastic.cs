using System;
using Nest;

namespace elastic_search_big_data
{
    public class AddToElastic
    {
        private readonly IElasticClient elasticClient;
        public AddToElastic(IElasticClient elasticClient)
        {
            this.elasticClient = elasticClient;
            
        }
        public async Task AddData(IEnumerable<Data> datas) {
            var index = "netflixdata";
            var batchSize = 100;
            var shiped = 0;

            var indexExistsResponse = await elasticClient.Indices.ExistsAsync(index);
            if (!indexExistsResponse.Exists)
            {
                var createIndexResponse = await elasticClient.Indices.CreateAsync(index, c => c
                    .Map<Data>(m => m.AutoMap())
                );

                if (!createIndexResponse.IsValid)
                {
                    Console.WriteLine($"Failed to create index: {createIndexResponse.OriginalException}");
                    // Handle the error
                    return;
                }
            }

            while(datas.Skip(shiped).Take(batchSize).Any()) {
                var batch = datas.Skip(shiped).Take(batchSize);
                var response = await elasticClient.BulkAsync(b => b.CreateMany(batch).Index(index));
                shiped += batchSize;

                if (response.IsValid)
                {
                    Console.WriteLine("Bulk operation was successful.");
                }
                else
                {
                    Console.WriteLine($"Bulk operation failed: {response.OriginalException}");
                    // Handle the error
                }

                foreach (var item in response.Items)
                {
                    if (!item.IsValid)
                    {
                        Console.WriteLine($"Item failed: {item.Error}");
                        // Handle the error
                    }
                }
            }

        }
    }
}
