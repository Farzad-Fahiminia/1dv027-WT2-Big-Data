﻿using Elasticsearch.Net;
using Microsoft.Extensions.DependencyInjection;
using Nest;
using elastic_search_big_data;

// var connectionSettings = new ConnectionSettings(new Uri("https://localhost:9200"));
var connectionSettings = new ConnectionSettings(new Uri("https://rzyjbdd2nz:eqqwludo90@big-data-search-7112089979.eu-central-1.bonsaisearch.net:443"));
connectionSettings.DisableDirectStreaming();
// connectionSettings.BasicAuthentication("elastic", "4dmZj0x5TKv2pWIKqa1A");
// connectionSettings.BasicAuthentication("rzyjbdd2nz", "eqqwludo90");
connectionSettings.ServerCertificateValidationCallback(CertificateValidations.AllowAll);

var elasticClient = new ElasticClient(connectionSettings);

var serviceProvider = new ServiceCollection()
    .AddSingleton<IUhrScraper, UhrScraper>()
    .AddSingleton<AddToElastic>()
    .AddSingleton<IElasticClient>(elasticClient)
    .BuildServiceProvider();

var uhrScraper = serviceProvider.GetService<IUhrScraper>();
var addToElastic = serviceProvider.GetService<AddToElastic>();
var data = await uhrScraper.GetData();
await addToElastic.AddData(data);
