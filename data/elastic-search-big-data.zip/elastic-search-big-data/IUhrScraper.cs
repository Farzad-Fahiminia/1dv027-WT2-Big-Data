using System;

namespace elastic_search_big_data
{
    public interface IUhrScraper
    {
        public Task<IEnumerable<Data>> GetData();
    }
}
