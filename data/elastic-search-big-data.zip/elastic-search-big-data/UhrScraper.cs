using System;
using System.Globalization;
using CsvHelper;
using CsvHelper.Configuration;
using Microsoft.VisualBasic.FileIO;

namespace elastic_search_big_data
{
  public class UhrScraper : IUhrScraper
  {
    public async Task<IEnumerable<Data>> GetData()
    {
      var data = new List<Data>();
      var parser = new TextFieldParser("/Users/farzad/1dv027/examination/elastic-search-big-data/titles.csv")
      { TextFieldType = FieldType.Delimited };

      parser.SetDelimiters(",");

      if (!parser.EndOfData) { parser.ReadFields(); }

      while (!parser.EndOfData) {
        try
        {
          var columns = parser.ReadFields();
          var movieObject = new Data
          {
            title = columns[1],
            type = columns[2],
            description = columns[3],
            release_year = int.Parse(columns[4]),
            runtime = int.Parse(columns[6]),
            imdb_score = float.Parse(columns[11])
          };

          data.Add(movieObject);
        }
        catch (System.Exception e)
        {
          Console.WriteLine(e);
        }
      };
      // var csv = new CsvReader(reader, CultureInfo.InvariantCulture);
      // var titles = csv.GetRecords<Data>().ToList();

      // csv.Context.RegisterClassMap<ModelClassMap>();
      // var titles = csv.GetRecords<Data>();
      // Console.WriteLine(movies);
      /* foreach (var movie in movies) {
        Console.WriteLine($"{movie.title}");
      } */
      return data;
    }
  }
}


    public class Data
{
    public string id { get; set; }
    public string title { get; set; }
    public string type { get; set; }
    public string description { get; set; }
    public int release_year { get; set; }
    public string age_certification { get; set; }
    public int runtime { get; set; }
    public string genres { get; set; }
    public string production_countries { get; set; }
    public string seasons { get; set; }
    public string imdb_id { get; set; }
    public float? imdb_score { get; set; }
    public string imdb_votes { get; set; }
    public string tmdb_popularity { get; set; }
    public string tmdb_score { get; set; }
}

public class ModelClassMap : ClassMap<Data>
{
    public ModelClassMap()
    {
        Map(m => m.id).Name("id");
        Map(m => m.title).Name("title");
        Map(m => m.type).Name("type");
        Map(m => m.description).Name("description");
        Map(m => m.release_year).Name("release_year");
        Map(m => m.age_certification).Name("age_certification");
        Map(m => m.runtime).Name("runtime");
        Map(m => m.genres).Name("genres");
        Map(m => m.production_countries).Name("production_countries");
        Map(m => m.seasons).Name("seasons");
        Map(m => m.imdb_id).Name("imdb_id");
        Map(m => m.imdb_score).Name("imdb_score");
        Map(m => m.imdb_votes).Name("imdb_votes");
        Map(m => m.tmdb_popularity).Name("tmdb_popularity");
        Map(m => m.tmdb_score).Name("tmdb_score");
    }
}
